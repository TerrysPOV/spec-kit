#!/usr/bin/env bash
set -euo pipefail
echo "[merge-audits] Using reports/security/plan-scan.md as merged output" >&2
